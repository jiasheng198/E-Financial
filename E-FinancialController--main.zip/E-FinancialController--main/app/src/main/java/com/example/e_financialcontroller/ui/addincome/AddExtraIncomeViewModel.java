package com.example.e_financialcontroller.ui.addincome;

import androidx.lifecycle.ViewModel;

public class AddExtraIncomeViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}