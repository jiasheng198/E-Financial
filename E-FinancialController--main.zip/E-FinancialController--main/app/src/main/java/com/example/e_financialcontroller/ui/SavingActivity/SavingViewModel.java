package com.example.e_financialcontroller.ui.SavingActivity;

import androidx.lifecycle.ViewModel;

public class SavingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}