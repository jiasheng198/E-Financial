package com.example.e_financialcontroller.ui.addnewincome;

import androidx.lifecycle.ViewModel;

public class AddNewIncomeViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}