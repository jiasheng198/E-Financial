package com.example.e_financialcontroller.ui.ExpensesCategoriesActivity;

import androidx.lifecycle.ViewModel;

public class ExpensesCategoriesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}